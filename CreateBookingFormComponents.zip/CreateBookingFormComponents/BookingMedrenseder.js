import React, { Component } from 'react';
import { InputNumber } from 'antd';
export default class BookingMedrenseder extends Component {
    onChange = (value) => {
        console.log('changed', value);
    }
    render() {
        return (
            <div>
                <InputNumber placeholder="Barn(0-6 ar)" size="large" min={1} max={100000} onChange={this.onChange} />
                <InputNumber placeholder="Ungdom(7-19 ar)"size="large"  min={1} max={100000}  onChange={this.onChange} />
                <InputNumber placeholder="Vuxen(0-6 ar)" size="large" min={1} max={100000} onChange={this.onChange} />
            </div>
        );
    }
}

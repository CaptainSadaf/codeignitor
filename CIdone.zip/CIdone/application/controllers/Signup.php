<?php
class Signup extends MY_Controller 
{
	public function sign_up()
	{
		$config = [
			'upload_path'	=>		'./uploads',
			'allowed_types'	=>		'jpg|gif|png|jpeg',
			];
		$this->load->library('upload', $config);
		$this->load->library('form_validation');
		if( $this->form_validation->run('add_signup_rules') && $this->upload->do_upload('image') ) {
			$post = $this->input->post();
			unset($post['submit']);
			$data = $this->upload->data();
			$image_path = base_url("uploads/" . $data['raw_name'] . $data['file_ext']);
			$post['image_path'] = $image_path;
					if($this->userss->add_users($post))
					{
						$this->load->view('admin/dashboard');
					}
					
		} else {
			$this->load->view('public/signup_users');
		}
	}
	public function __construct()
	{
		parent::__construct();
		  if($this->session->userdata('user_id') )
			return redirect('admin/dashboard');
		$this->load->model('signupmodel','userss');
		$this->load->helper('form');
	}

	
}
<?php

$config = [

		'add_signup_rules'		=>	[
														[
															'field'	=>	'uname',
															'label'	=>	'User Name',
															'rules'	=>	'required|alphadash'
														],
														[
															'field'	=>	'password',
															'label'	=>	'Password',
															'rules'	=>	'required',
														],
														[
															'field'	=>	'repassword',
															'label'	=>	'Re Password',
															'rules'	=>	'trim|required|matches[password]',
														],
														[
															'field'	=>	'firstname',
															'label'	=>	'First name',
															'rules'	=>	'required',
														],
														[
															'field'	=>	'lastname',
															'label'	=>	'Last name',
															'rules'	=>	'required',
														]
														
														],
														
							
		'admin_login'			=>	[
														[
															'field'	=>	'username',
															'label'	=>	'User Name',
															'rules'	=>	'required|alpha|trim',
														],
														[
															'field'	=>	'password',
															'label'	=>	'Password',
															'rules'	=>	'required',
														]
									]


];
<?php

class Signupmodel extends CI_Model {

	public function add_users($array)
	{
		 return $this->db->insert( 'userss', $array );
	}

}




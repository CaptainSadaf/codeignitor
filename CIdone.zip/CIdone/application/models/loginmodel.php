<?php

class Loginmodel extends CI_Model {
	public function login_valid( $username, $password )
	{
		$q = $this->db->where(['uname'=>$username,'password'=>$password])
						->get('userss');

		if ( $q->num_rows() ) {
			return $q->row()->id;
			// return TRUE;
		} else {
			return FALSE;
		}
	}

}
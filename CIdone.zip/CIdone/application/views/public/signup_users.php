<?php include('public_header.php'); ?>

<div class="container">
	<?php echo form_open_multipart('Signup/sign_up', ['class'=>'form-horizontal']) ?>
	
  <fieldset>
    <legend>Sign Up</legend>
    
    <div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">User Name</label>
      <div class="col-lg-8">
      <?php echo form_input(['name'=>'uname','class'=>'form-control','placeholder'=>'User Name','value'=>set_value('uname')]); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php echo form_error('uname'); ?>
      </div>
    </div>
	
	 <div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">Password</label>
      <div class="col-lg-8">
      <?php echo form_input(['name'=>'password','class'=>'form-control','placeholder'=>'password','value'=>set_value('password')]); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php echo form_error('password'); ?>
      </div>
    </div>
	
	<div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">Re Password</label>
      <div class="col-lg-8">
      <?php echo form_input(['name'=>'repassword','class'=>'form-control','placeholder'=>'repassword','value'=>set_value('repassword')]); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php echo form_error('repassword'); ?>
      </div>
    </div>
	
	<div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">First Name</label>
      <div class="col-lg-8">
      <?php echo form_input(['name'=>'firstname','class'=>'form-control','placeholder'=>'firstname','value'=>set_value('firstname')]); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php echo form_error('firstname'); ?>
      </div>
    </div>
	
	<div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">Last Name</label>
      <div class="col-lg-8">
      <?php echo form_input(['name'=>'lastname','class'=>'form-control','placeholder'=>'lastname','value'=>set_value('lastname')]); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php echo form_error('lastname'); ?>
      </div>
    </div>
	
    <div class="row">
      <div class="col-lg-6">
        <div class="form-group">
      <label for="inputEmail" class="col-lg-4 control-label">Select Image</label>
      <div class="col-lg-8">

      <?php echo form_upload(['name'=>'image','class'=>'form-control']); ?>
      </div>
    </div>
      </div>
      <div class="col-lg-6">
        <?php if(isset($upload_error)) echo $upload_error ?>
      </div>
    </div>
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">

        <?php 
        	echo form_reset(['name'=>'reset','value'=>'Reset','class'=>'btn btn-default']),
        		form_submit(['name'=>'submit','value'=>'Submit','class'=>'btn btn-primary']);
        ?>
      </div>
    </div>
  </fieldset>
</form>
</div>

<?php include_once('public_footer.php'); ?>
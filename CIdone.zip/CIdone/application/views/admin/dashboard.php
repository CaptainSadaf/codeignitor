<?php include_once('admin_header.php'); ?>


<div class="container">
Success Done!
	<div class="row">
		<div class="col-lg-6 col-lg-offset-6">
		<?= anchor('login','Add More Info',['class'=>'btn btn-lg btn-primary pull-right']) ?>
			
	</div>
</div>
<?php include_once('admin_footer.php'); ?>